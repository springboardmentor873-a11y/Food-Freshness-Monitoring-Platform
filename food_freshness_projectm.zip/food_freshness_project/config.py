"""
Central configuration for the Food Freshness Classifier project.
Change paths/hyperparameters here — nothing else in the codebase should
hardcode these values.
"""

import os

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
# Point this at wherever you unzipped the Kaggle dataset. Expected layout
# (ImageFolder style — one sub-folder per class):
#
#   RAW_DATA_DIR/
#       fresh_bread/
#       spoiled_bread/
#       fresh_dairy/
#       spoiled_dairy/
#       fresh_fruit/
#       spoiled_fruit/
#       fresh_vegetable/
#       spoiled_vegetable/
#
# If your folder names differ, either rename them to match, or edit
# CLASS_NAMES below to match your actual folder names exactly.
RAW_DATA_DIR = os.environ.get("FOOD_DATA_DIR", "./data/raw")
SPLIT_DATA_DIR = "./data/split"          # created by prepare_data_split.py
MODEL_DIR = "./outputs/models"
LOG_DIR = "./outputs/logs"
PLOT_DIR = "./outputs/plots"

for d in [SPLIT_DATA_DIR, MODEL_DIR, LOG_DIR, PLOT_DIR]:
    os.makedirs(d, exist_ok=True)

# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
IMG_SIZE = (224, 224)          # EfficientNetB0 native input size
BATCH_SIZE = 32
SEED = 42

TRAIN_SPLIT = 0.70
VAL_SPLIT = 0.15
TEST_SPLIT = 0.15

# Leave empty to auto-detect from folder names at split time. Auto-detected
# names are sorted alphabetically and saved to outputs/models/class_names.json
# so training/eval/inference always agree on the label order.
CLASS_NAMES = []

# ---------------------------------------------------------------------------
# Model / training
# ---------------------------------------------------------------------------
BACKBONE = "ResNet50"            # options: EfficientNetB0, EfficientNetB3, ResNet50
DROPOUT_RATE = 0.5
L2_REG = 2e-4
LABEL_SMOOTHING = 0.1

# Phase 1: train only the classification head, backbone frozen
PHASE1_EPOCHS = 15
PHASE1_LR = 1e-3

# Phase 2: unfreeze the top portion of the backbone and fine-tune slowly
PHASE2_EPOCHS = 20
PHASE2_LR = 5e-5
UNFREEZE_LAST_N_LAYERS = 12

EARLY_STOPPING_PATIENCE = 6
REDUCE_LR_PATIENCE = 3
REDUCE_LR_FACTOR = 0.5
MIN_LR = 1e-7