# Food Freshness Classifier

Predicts food freshness from images using transfer learning on
**EfficientNetB0**, then derives three downstream outputs from that
prediction:

1. **Freshness Category** — learned directly (fresh/spoiled × food type)
2. **Freshness Score** — calibrated from model confidence
3. **Remaining Shelf Life** — rule-based, scaled by freshness score
4. **Storage Recommendation** — rule-based lookup by food type + state

Built for the [Fresh and Spoiled Food Image Dataset](https://www.kaggle.com/datasets/maheen00shahid/fresh-and-spoiled-food-image-dataset)
(8-class: fresh/spoiled × bread, dairy, fruit, vegetable).

---

## Why EfficientNetB0, and why only outputs #1 is "learned"

**Model choice.** This dataset is small and single-domain — nowhere near
ImageNet scale. A bigger backbone (ResNet152, ConvNeXtLarge, etc.) has
far more capacity to memorize training images rather than learn
generalizable freshness cues, so it tends to overfit *harder*, not less,
on data this size. EfficientNetB0 (5.3M params) has the best
accuracy-per-parameter ratio of the standard Keras Applications models,
which is exactly the property you want here. `config.py` has
EfficientNetB3 as a documented one-line fallback if B0 turns out to
underfit on your actual data.

**Output scope.** The raw dataset only contains fresh/spoiled labels per
food type — it has no continuous freshness score, no day-count shelf-life
labels, and no storage-recommendation labels. Those can't be *learned*
from this data as-is. Rather than inventing training targets that don't
exist, `src/rules.py` derives them transparently from the classifier's
predicted class and confidence. If you later get labeled shelf-life data
(e.g. images tagged with days-since-purchase), swap that module for a
second trained regression head — the architecture is built to make that
swap easy (see "Extending" below).

---

## Project structure

```
food_freshness_project/
├── config.py                  # all hyperparameters & paths, edit here
├── prepare_data_split.py      # stratified train/val/test split
├── requirements.txt
├── src/
│   ├── data_pipeline.py       # tf.data loaders, augmentation, class weights
│   ├── model.py                # EfficientNetB0 architecture + fine-tune logic
│   ├── train.py                # two-phase training loop
│   ├── evaluate.py             # confusion matrix, report, overfit check plots
│   ├── rules.py                 # score / shelf-life / storage rule engine
│   └── predict.py               # single-image end-to-end inference
└── outputs/
    ├── models/                  # saved checkpoints, class_names.json
    ├── logs/                    # CSV training logs, classification report
    └── plots/                   # training curves, confusion matrix
```

---

## Setup

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

Download the dataset from Kaggle and unzip it, then point the project at it:

```bash
export FOOD_DATA_DIR=/path/to/unzipped/dataset
```

The pipeline expects one folder per class:

```
FOOD_DATA_DIR/
├── fresh_bread/
├── spoiled_bread/
├── fresh_dairy/
├── spoiled_dairy/
├── fresh_fruit/
├── spoiled_fruit/
├── fresh_vegetable/
└── spoiled_vegetable/
```

If your downloaded folder names differ, either rename them to match, or
edit `parse_class_name()` in `src/rules.py` to match your naming
convention (it currently expects `<state>_<foodtype>`).

---

## Running it

```bash
# 1. Stratified split into train/val/test (70/15/15 by default)
python prepare_data_split.py

# 2. Clean dataset
python clean_dataset.py --dir data/split --dry-run
python clean_dataset.py --dir data/split

# 3. Train (two phases: frozen backbone, then fine-tune top layers)
python -m src.train

# 4. Evaluate: classification report, confusion matrix, overfit-check plots
python -m src.evaluate

# 5. Predict on a single image
python -m src.predict --image /path/to/some_food.jpg
```

`train.py` prints the train-vs-test accuracy gap at the end and flags it
if it exceeds 10 points — that gap is the actual overfitting signal to
watch, not train accuracy alone.

---

## How overfitting is controlled (concretely)

| Technique | Where |
|---|---|
| Transfer learning from ImageNet weights | `model.py` |
| Backbone frozen for phase 1, only head trains | `model.py`, `train.py` |
| Only top N layers unfrozen in phase 2, BatchNorm layers stay frozen | `model.py: unfreeze_for_finetune()` |
| Data augmentation (flip, rotation, zoom, translation, color/brightness jitter) — train set only | `data_pipeline.py` |
| Dropout (0.4) + L2 regularization on the dense head | `model.py` |
| Label smoothing (0.1) | `model.py` |
| Class weighting for imbalanced classes | `data_pipeline.py: compute_class_weights()` |
| Early stopping on validation accuracy | `train.py` |
| ReduceLROnPlateau on validation loss | `train.py` |
| Held-out test set never touched until final evaluation | `prepare_data_split.py`, `train.py` |
| GlobalAveragePooling instead of Flatten (fewer head parameters) | `model.py` |

---

## Getting accuracy higher, in priority order

If test accuracy isn't where you want it after a first run, try these in
this order — they matter roughly this much:

1. **More/better data beats a bigger model almost every time.** Check
   `prepare_data_split.py`'s class-count warning — if a class has far
   fewer images than others, that class will underperform regardless of
   architecture.
2. **Increase `UNFREEZE_LAST_N_LAYERS`** in `config.py` moderately (e.g.
   30 → 60) if train accuracy is also plateauing low (that's underfitting,
   not overfitting — the fix is different).
3. **Step up to EfficientNetB3** (`config.BACKBONE = "EfficientNetB3"`)
   only if B0 is clearly underfitting (both train and val accuracy low)
   — not if it's overfitting (train high, val low).
4. **Tune augmentation strength** — if val accuracy is unstable epoch to
   epoch, augmentation may be too aggressive for this domain; dial back
   `RandomBrightness`/`RandomContrast` first since spoilage cues are
   color-dependent.
5. **Longer phase-2 fine-tuning** with a lower learning rate, if the
   gap is small but both accuracies are still climbing at training end.

Do **not** reach for a bigger backbone as the first move — on a dataset
this size it's the move most likely to *increase* the overfitting gap
rather than close it.

---

## Extending to real shelf-life data

If you later obtain images labeled with actual days-since-purchase or
verified shelf-life values:

1. Add a regression head in `model.py` alongside the classification head
   (multi-output `tf.keras.Model` with two losses: categorical
   crossentropy for category, MSE for shelf life).
2. Replace the shelf-life portion of `derive_outputs()` in `rules.py`
   with the new head's prediction.
3. Same applies to storage recommendations if you ever have
   supervision for them (e.g. a labeled multi-class field) — swap the
   lookup table for a third head.

---

## Known limitations

- Freshness score, remaining shelf life, and storage recommendation are
  **derived heuristically**, not learned — treat them as reasonable
  defaults to refine with domain expertise, not validated predictions.
- The rule engine's shelf-life baselines (`SHELF_LIFE_DAYS_FRESH` in
  `rules.py`) are rough defaults and should be adjusted to your actual
  food sub-categories and storage conditions.
- Only the four top-level food groups (bread, dairy, fruit, vegetable)
  are modeled; performance on food types outside these categories is
  undefined.
