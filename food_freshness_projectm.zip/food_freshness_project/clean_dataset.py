"""
Scans an image directory tree and fixes files that will crash
tf.keras.utils.image_dataset_from_directory with:
    "Unknown image file format. One of JPEG, PNG, GIF, BMP required."

This happens when a file's extension says .jpg/.png but the actual file
bytes are something else (commonly WebP from scraped datasets), or when
the file is truncated/corrupted.

For each image file found, this script:
  - Corrupt / unreadable files          -> moved to a quarantine folder
  - Readable but wrong format (e.g. WebP, TIFF) -> converted to JPEG in place
  - Valid JPEG/PNG/GIF/BMP              -> left untouched

Run this BEFORE prepare_data_split.py (on the raw dataset), or point it
directly at data/split if you've already split and don't want to redo it —
it's safe to run on any directory tree of images.

Usage:
    python clean_dataset.py --dir ./data/raw
    python clean_dataset.py --dir ./data/split
"""

import argparse
import shutil
from pathlib import Path

from PIL import Image, UnidentifiedImageError

VALID_TF_FORMATS = {"JPEG", "PNG", "GIF", "BMP"}
IMG_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".bmp",
                   ".webp", ".tiff", ".tif", ".avif"}


def find_image_files(root_dir):
    root = Path(root_dir)
    return [f for f in root.rglob("*")
            if f.is_file() and f.suffix.lower() in IMG_EXTENSIONS]


def clean(root_dir, quarantine_dir=None, dry_run=False):
    root = Path(root_dir)
    quarantine_dir = Path(quarantine_dir or (root.parent / "quarantined_images"))

    files = find_image_files(root)
    print(f"Scanning {len(files)} image files under {root} ...")

    n_ok = 0
    n_converted = 0
    n_quarantined = 0

    for f in files:
        try:
            with Image.open(f) as img:
                img.verify()  # cheap corruption check, doesn't decode pixels
            with Image.open(f) as img:
                fmt = img.format
                mode = img.mode

                if fmt in VALID_TF_FORMATS:
                    n_ok += 1
                    continue

                # Readable, but not a format TF's decoder accepts.
                # Convert to JPEG in place (same folder, same class label).
                if dry_run:
                    print(f"[would convert] {f}  ({fmt} -> JPEG)")
                    n_converted += 1
                    continue

                rgb_img = img.convert("RGB") if mode != "RGB" else img
                new_path = f.with_suffix(".jpg")
                rgb_img.save(new_path, "JPEG", quality=95)
                if new_path != f:
                    f.unlink()  # remove the original non-jpeg file
                n_converted += 1
                print(f"[converted] {f.name}  ({fmt} -> JPEG)")

        except (UnidentifiedImageError, OSError, SyntaxError) as e:
            # Genuinely unreadable/corrupt -- quarantine rather than
            # silently delete, so nothing is lost without a chance to check.
            n_quarantined += 1
            if dry_run:
                print(f"[would quarantine] {f}  ({e})")
                continue
            rel = f.relative_to(root)
            dest = quarantine_dir / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(f), str(dest))
            print(f"[quarantined] {f.name}  ({e})")

    print("\n" + "=" * 50)
    print("CLEANING SUMMARY")
    print("=" * 50)
    print(f"  Already valid:      {n_ok}")
    print(f"  Converted to JPEG:  {n_converted}")
    print(f"  Quarantined (bad):  {n_quarantined}")
    if n_quarantined and not dry_run:
        print(f"  Quarantined files moved to: {quarantine_dir}")
    print("=" * 50)

    if dry_run:
        print("\nThis was a dry run — nothing was changed. "
              "Re-run without --dry-run to apply fixes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", required=True,
                         help="Directory to scan recursively (e.g. ./data/raw or ./data/split)")
    parser.add_argument("--quarantine-dir", default=None,
                         help="Where to move unreadable files (default: <parent>/quarantined_images)")
    parser.add_argument("--dry-run", action="store_true",
                         help="Report what would change without modifying any files")
    args = parser.parse_args()

    clean(args.dir, args.quarantine_dir, args.dry_run)