"""
Splits the raw Kaggle dataset (one folder per class) into a stratified
train / val / test split on disk, e.g.:

    data/split/train/fresh_bread/*.jpg
    data/split/val/fresh_bread/*.jpg
    data/split/test/fresh_bread/*.jpg

A held-out test set matters here specifically to catch overfitting: if
train accuracy is high but test accuracy lags well behind it, that's the
overfitting signal to watch for during training.

Run once before train.py:
    python prepare_data_split.py
"""

import os
import shutil
import random
from pathlib import Path

import config


def list_classes(raw_dir):
    classes = sorted(
        [d.name for d in Path(raw_dir).iterdir() if d.is_dir()]
    )
    if not classes:
        raise RuntimeError(
            f"No class folders found under {raw_dir}. "
            "Point config.RAW_DATA_DIR at the unzipped Kaggle dataset."
        )
    return classes


def split_list(items, train_ratio, val_ratio):
    n = len(items)
    n_train = int(n * train_ratio)
    n_val = int(n * val_ratio)
    return items[:n_train], items[n_train:n_train + n_val], items[n_train + n_val:]


def main():
    random.seed(config.SEED)
    classes = list_classes(config.RAW_DATA_DIR)
    print(f"Found {len(classes)} classes: {classes}")

    summary = {}
    for cls in classes:
        src_dir = Path(config.RAW_DATA_DIR) / cls
        files = [f for f in src_dir.iterdir() if f.suffix.lower() in
                 {".jpg", ".jpeg", ".png", ".bmp"}]
        random.shuffle(files)

        train_files, val_files, test_files = split_list(
            files, config.TRAIN_SPLIT, config.VAL_SPLIT
        )

        for split_name, split_files in [
            ("train", train_files), ("val", val_files), ("test", test_files)
        ]:
            out_dir = Path(config.SPLIT_DATA_DIR) / split_name / cls
            out_dir.mkdir(parents=True, exist_ok=True)
            for f in split_files:
                shutil.copy2(f, out_dir / f.name)

        summary[cls] = {
            "total": len(files),
            "train": len(train_files),
            "val": len(val_files),
            "test": len(test_files),
        }

    print("\nSplit summary:")
    print(f"{'class':25s} {'total':>6s} {'train':>6s} {'val':>6s} {'test':>6s}")
    for cls, s in summary.items():
        print(f"{cls:25s} {s['total']:6d} {s['train']:6d} {s['val']:6d} {s['test']:6d}")

    # Flag class imbalance early — it's one of the more common causes of a
    # model that looks accurate overall but fails badly on minority classes.
    totals = [s["total"] for s in summary.values()]
    if max(totals) / max(min(totals), 1) > 3:
        print(
            "\n[WARNING] Class sizes are heavily imbalanced "
            f"(largest {max(totals)} vs smallest {min(totals)}). "
            "train.py computes class weights automatically to compensate, "
            "but consider augmenting the smaller classes too."
        )


if __name__ == "__main__":
    main()
