"""
Trains the freshness classifier in two phases and saves the best checkpoint
by validation accuracy (not training accuracy — training accuracy alone
tells you nothing about overfitting).

Usage:
    python -m src.train
"""

import json
import os
from pathlib import Path

import tensorflow as tf

import config
from src.data_pipeline import get_datasets, compute_class_weights
from src.model import build_model, compile_model, unfreeze_for_finetune


def build_callbacks(checkpoint_path, log_name):
    return [
        tf.keras.callbacks.ModelCheckpoint(
            filepath=str(checkpoint_path),
            monitor="val_accuracy",
            save_best_only=True,
            mode="max",
            verbose=1,
        ),
        tf.keras.callbacks.EarlyStopping(
            monitor="val_accuracy",
            patience=config.EARLY_STOPPING_PATIENCE,
            restore_best_weights=True,
            mode="max",
            verbose=1,
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=config.REDUCE_LR_FACTOR,
            patience=config.REDUCE_LR_PATIENCE,
            min_lr=config.MIN_LR,
            verbose=1,
        ),
        tf.keras.callbacks.CSVLogger(
            str(Path(config.LOG_DIR) / f"{log_name}.csv")
        ),
    ]


def main():
    train_ds, val_ds, test_ds, class_names = get_datasets()
    num_classes = len(class_names)
    class_weights = compute_class_weights(class_names)
    print(f"Classes ({num_classes}): {class_names}")
    print(f"Class weights: {class_weights}")

    model, base = build_model(num_classes)
    compile_model(model, config.PHASE1_LR)
    model.summary()

    # --- Phase 1: train head only, backbone frozen ---
    print("\n=== Phase 1: training classification head (backbone frozen) ===")
    phase1_ckpt = Path(config.MODEL_DIR) / "phase1_best.keras"
    history1 = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=config.PHASE1_EPOCHS,
        class_weight=class_weights,
        callbacks=build_callbacks(phase1_ckpt, "phase1"),
    )

    # --- Phase 2: unfreeze top of backbone, fine-tune at low LR ---
    print("\n=== Phase 2: fine-tuning top backbone layers ===")
    unfreeze_for_finetune(base)
    compile_model(model, config.PHASE2_LR)  # recompile after trainable change

    phase2_ckpt = Path(config.MODEL_DIR) / "phase2_best.keras"
    history2 = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=config.PHASE2_EPOCHS,
        class_weight=class_weights,
        callbacks=build_callbacks(phase2_ckpt, "phase2"),
    )

    # --- Final evaluation on held-out test set ---
    print("\n=== Final evaluation on held-out TEST set ===")
    test_results = model.evaluate(test_ds, return_dict=True)
    train_results = model.evaluate(train_ds, return_dict=True)

    print(f"Train accuracy: {train_results['accuracy']:.4f}")
    print(f"Test accuracy:  {test_results['accuracy']:.4f}")
    gap = train_results["accuracy"] - test_results["accuracy"]
    print(f"Train-test accuracy gap: {gap:.4f}")
    if gap > 0.10:
        print(
            "[WARNING] Train-test gap exceeds 10 points — likely still "
            "overfitting. Consider: more augmentation, stronger dropout, "
            "fewer unfrozen layers, or gathering more data."
        )
    else:
        print("[OK] Train-test gap is within a healthy range.")

    # Save final model + metadata
    final_path = Path(config.MODEL_DIR) / "freshness_classifier_final.keras"
    model.save(final_path)

    with open(Path(config.MODEL_DIR) / "training_summary.json", "w") as f:
        json.dump({
            "class_names": class_names,
            "train_accuracy": float(train_results["accuracy"]),
            "test_accuracy": float(test_results["accuracy"]),
            "test_loss": float(test_results["loss"]),
            "train_test_gap": float(gap),
        }, f, indent=2)

    print(f"\nFinal model saved to: {final_path}")


if __name__ == "__main__":
    main()
