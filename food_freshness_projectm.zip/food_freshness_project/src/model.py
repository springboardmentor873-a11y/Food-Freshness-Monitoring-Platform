"""
EfficientNetB0-based transfer-learning classifier for the freshness
category task (fresh/spoiled x food type).

Design choices, and why:
  - EfficientNetB0 backbone: best accuracy-per-parameter in the
    Keras Applications lineup, which matters a lot on a dataset this
    small — a bigger backbone (ResNet152, ConvNeXtLarge, etc.) has far
    more capacity to memorize the training set instead of learning
    generalizable freshness cues.
  - GlobalAveragePooling instead of Flatten: far fewer parameters going
    into the head, which is itself a regularizer.
  - Dropout + L2 on the dense head: standard overfitting control.
  - Two-phase training (frozen -> partial fine-tune): protects the
    pretrained ImageNet features early on, then lets the top of the
    network adapt to food-specific texture/color cues without wrecking
    the low-level features that generalize well.
"""

import tensorflow as tf
from tensorflow.keras import layers, regularizers

import config


def build_model(num_classes, backbone_name=None):
    backbone_name = backbone_name or config.BACKBONE

    if backbone_name == "EfficientNetB0":
        base = tf.keras.applications.EfficientNetB0(
            include_top=False, weights="imagenet",
            input_shape=config.IMG_SIZE + (3,),
        )
    elif backbone_name == "EfficientNetB3":
        base = tf.keras.applications.EfficientNetB3(
            include_top=False, weights="imagenet",
            input_shape=config.IMG_SIZE + (3,),
        )
    elif backbone_name == "ResNet50":
        base = tf.keras.applications.ResNet50(
            include_top=False, weights="imagenet",
            input_shape=config.IMG_SIZE + (3,),
        )
    else:
        raise ValueError(f"Unsupported backbone: {backbone_name}")

    base.trainable = False  # Phase 1: frozen backbone

    inputs = tf.keras.Input(shape=config.IMG_SIZE + (3,))
    x = base(inputs, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(config.DROPOUT_RATE)(x)
    x = layers.Dense(
        256, activation="relu",
        kernel_regularizer=regularizers.l2(config.L2_REG),
    )(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(config.DROPOUT_RATE)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    model = tf.keras.Model(inputs, outputs, name=f"{backbone_name}_freshness")
    return model, base


def compile_model(model, learning_rate):
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss=tf.keras.losses.CategoricalCrossentropy(
            label_smoothing=config.LABEL_SMOOTHING
        ),
        metrics=[
            "accuracy",
            tf.keras.metrics.TopKCategoricalAccuracy(k=2, name="top2_accuracy"),
        ],
    )
    return model


def unfreeze_for_finetune(base_model, n_layers=None):
    """Unfreeze only the last n_layers of the backbone. Keeping the early
    layers frozen preserves general-purpose low-level filters (edges,
    color gradients, textures) learned from ImageNet, which is what
    prevents fine-tuning from immediately overfitting a small dataset."""
    n_layers = n_layers or config.UNFREEZE_LAST_N_LAYERS
    base_model.trainable = True
    for layer in base_model.layers[:-n_layers]:
        layer.trainable = False
    # BatchNorm layers should stay in inference mode even when "trainable",
    # otherwise fine-tuning BN statistics on a small dataset destabilizes
    # training.
    for layer in base_model.layers:
        if isinstance(layer, tf.keras.layers.BatchNormalization):
            layer.trainable = False
    return base_model
