"""
Runs the full pipeline on a single image: trained classifier -> rule
engine -> all four required outputs.

Usage:
    python -m src.predict --image path/to/food.jpg
"""

import argparse
import json
from pathlib import Path

import numpy as np
import tensorflow as tf

import config
from src.rules import derive_outputs


def _get_preprocess_fn():
    if config.BACKBONE == "ResNet50":
        from tensorflow.keras.applications.resnet50 import preprocess_input
    else:
        from tensorflow.keras.applications.efficientnet import preprocess_input
    return preprocess_input


def load_class_names():
    with open(Path(config.MODEL_DIR) / "class_names.json") as f:
        return json.load(f)


def predict(image_path, model=None, class_names=None):
    if model is None:
        model_path = Path(config.MODEL_DIR) / "freshness_classifier_final.keras"
        model = tf.keras.models.load_model(model_path)
    if class_names is None:
        class_names = load_class_names()

    img = tf.keras.utils.load_img(image_path, target_size=config.IMG_SIZE)
    arr = tf.keras.utils.img_to_array(img)
    arr = _get_preprocess_fn()(arr)
    arr = np.expand_dims(arr, axis=0)

    probs = model.predict(arr, verbose=0)[0]
    pred_idx = int(np.argmax(probs))
    pred_class = class_names[pred_idx]
    confidence = float(probs[pred_idx])

    result = derive_outputs(pred_class, confidence)
    result["image_path"] = str(image_path)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True, help="Path to a food image")
    args = parser.parse_args()

    result = predict(args.image)
    print(f"\nPrediction confidence: {result['model_confidence'] * 100:.2f}%\n")
    print(json.dumps(result, indent=2))
