"""
Loads the trained model and produces:
  - classification report (precision/recall/F1 per class)
  - confusion matrix plot
  - train-vs-val accuracy/loss curves (the direct visual overfitting check)

Usage:
    python -m src.evaluate
"""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import classification_report, confusion_matrix

import config
from src.data_pipeline import get_datasets


def plot_training_curves():
    """Reads the CSVLogger output from both training phases and plots
    train vs val accuracy/loss on the same axes — the classic overfitting
    check: val curves diverging upward from train curves is the signal."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    for phase, style in [("phase1", "-"), ("phase2", "--")]:
        csv_path = Path(config.LOG_DIR) / f"{phase}.csv"
        if not csv_path.exists():
            continue
        df = pd.read_csv(csv_path)
        axes[0].plot(df["epoch"], df["accuracy"], style, label=f"{phase} train acc")
        axes[0].plot(df["epoch"], df["val_accuracy"], style, label=f"{phase} val acc")
        axes[1].plot(df["epoch"], df["loss"], style, label=f"{phase} train loss")
        axes[1].plot(df["epoch"], df["val_loss"], style, label=f"{phase} val loss")

    axes[0].set_title("Accuracy: train vs validation")
    axes[0].set_xlabel("epoch")
    axes[0].legend()
    axes[1].set_title("Loss: train vs validation")
    axes[1].set_xlabel("epoch")
    axes[1].legend()

    out_path = Path(config.PLOT_DIR) / "training_curves.png"
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    print(f"Saved training curves to {out_path}")


def evaluate_on_test():
    train_ds, val_ds, test_ds, class_names = get_datasets()

    model_path = Path(config.MODEL_DIR) / "freshness_classifier_final.keras"
    model = tf.keras.models.load_model(model_path)

    def run_eval(ds):
        y_true, y_pred = [], []
        for images, labels in ds:
            preds = model.predict(images, verbose=0)
            y_true.extend(np.argmax(labels.numpy(), axis=1))
            y_pred.extend(np.argmax(preds, axis=1))
        return np.array(y_true), np.array(y_pred)

    train_true, train_pred = run_eval(train_ds)
    val_true, val_pred = run_eval(val_ds)
    y_true, y_pred = run_eval(test_ds)

    train_acc = float(np.mean(train_true == train_pred))
    val_acc = float(np.mean(val_true == val_pred))
    test_acc = float(np.mean(y_true == y_pred))
    gap = train_acc - test_acc

    print("\n" + "=" * 50)
    print("ACCURACY SUMMARY")
    print("=" * 50)
    print(f"  Train accuracy:      {train_acc * 100:.2f}%")
    print(f"  Validation accuracy: {val_acc * 100:.2f}%")
    print(f"  Test accuracy:       {test_acc * 100:.2f}%")
    print(f"  Train-Test gap:      {gap * 100:.2f} points"
          + ("  [WARNING: possible overfitting]" if gap > 0.10 else "  [OK]"))
    print("=" * 50 + "\n")

    with open(Path(config.LOG_DIR) / "accuracy_summary.json", "w") as f:
        json.dump({
            "train_accuracy": train_acc,
            "val_accuracy": val_acc,
            "test_accuracy": test_acc,
            "train_test_gap": gap,
        }, f, indent=2)

    report = classification_report(
        y_true, y_pred, target_names=class_names, output_dict=True
    )
    print("Per-class report (test set):")
    print(classification_report(y_true, y_pred, target_names=class_names))

    with open(Path(config.LOG_DIR) / "classification_report.json", "w") as f:
        json.dump(report, f, indent=2)

    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(9, 8))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion matrix (test set)")
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im)
    fig.tight_layout()
    out_path = Path(config.PLOT_DIR) / "confusion_matrix.png"
    fig.savefig(out_path, dpi=150)
    print(f"Saved confusion matrix to {out_path}")


if __name__ == "__main__":
    plot_training_curves()
    evaluate_on_test()
