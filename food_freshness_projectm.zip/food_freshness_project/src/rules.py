"""
The Kaggle dataset only provides fresh/spoiled labels per food type — it
has no continuous freshness score, no day-count shelf-life labels, and no
storage-recommendation labels. Those three outputs can't be learned from
this data as-is, so they're derived here with a transparent rule engine
sitting on top of the trained classifier's output (predicted class +
confidence). Treat these numbers as reasonable defaults to refine with
domain expertise or additional labeled data, not as validated ground truth.

If you later get access to real shelf-life/day-count data (e.g. images
labeled with days-since-purchase), swap this module for a second trained
regression head instead of hardcoded rules.
"""

# Baseline shelf life (in days, from purchase, unopened, typically
# refrigerated where applicable) once graded "fresh". Adjust to match your
# actual food sub-categories.
SHELF_LIFE_DAYS_FRESH = {
    "bread": 5,
    "dairy": 7,
    "fruit": 6,
    "vegetable": 8,
}

STORAGE_RECOMMENDATIONS = {
    "bread": {
        "fresh": "Store in a cool, dry place in a sealed bag; refrigerate only to extend shelf life if not eating within 2-3 days.",
        "spoiled": "Discard. Do not consume moldy bread even if only part appears affected.",
    },
    "dairy": {
        "fresh": "Keep refrigerated at or below 4°C (40°F); reseal tightly after each use.",
        "spoiled": "Discard immediately. Spoiled dairy can contain harmful bacteria not eliminated by cooking.",
    },
    "fruit": {
        "fresh": "Store per fruit type — most are best refrigerated once ripe, some (bananas, citrus) at room temperature.",
        "spoiled": "Discard if mold, fermentation smell, or significant softening is present; small bruises can sometimes be trimmed.",
    },
    "vegetable": {
        "fresh": "Store in the refrigerator crisper drawer with adequate humidity; keep away from ethylene-producing fruits.",
        "spoiled": "Discard if slimy texture, discoloration, or off odor is present.",
    },
}


def parse_class_name(class_name):
    """Expects class names like 'fresh_bread' / 'spoiled_dairy'.
    Adjust this parser if your folder naming convention differs."""
    state, _, food_type = class_name.partition("_")
    return state.lower(), food_type.lower()


def derive_outputs(class_name, confidence):
    """
    Args:
        class_name: predicted class, e.g. 'fresh_dairy'
        confidence: softmax probability of the predicted class (0-1)

    Returns dict with all four required outputs.
    """
    state, food_type = parse_class_name(class_name)

    # Freshness Score: calibrated from model confidence, biased toward the
    # low end for anything predicted spoiled (spoiled-but-uncertain should
    # still read as "low freshness", not "50% fresh").
    if state == "fresh":
        freshness_score = round(50 + confidence * 50, 1)   # 50-100 range
    else:
        freshness_score = round((1 - confidence) * 50, 1)  # 0-50 range

    # Remaining shelf life: scales the baseline shelf life for that food
    # type by the freshness score. Spoiled items get 0.
    if state == "spoiled":
        remaining_days = 0
    else:
        base_days = SHELF_LIFE_DAYS_FRESH.get(food_type, 5)
        remaining_days = round(base_days * (freshness_score / 100), 1)

    storage_advice = STORAGE_RECOMMENDATIONS.get(
        food_type, {}
    ).get(state, "No storage recommendation available for this category.")

    return {
        "freshness_category": class_name,
        "freshness_score": freshness_score,
        "remaining_shelf_life_days": remaining_days,
        "storage_recommendation": storage_advice,
        "model_confidence": round(confidence, 4),
    }
