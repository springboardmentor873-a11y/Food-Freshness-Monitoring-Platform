"""
tf.data pipelines for train/val/test, plus class-weight computation.

Augmentation is applied ONLY to the training set. Validation and test sets
must stay clean, otherwise your val/test accuracy is not a trustworthy
signal of real-world generalization.
"""

import json
import os
from pathlib import Path

import numpy as np
import tensorflow as tf

import config


def _discover_class_names(split_dir):
    train_dir = Path(split_dir) / "train"
    return sorted([d.name for d in train_dir.iterdir() if d.is_dir()])


def get_class_names():
    if config.CLASS_NAMES:
        return config.CLASS_NAMES
    class_names = _discover_class_names(config.SPLIT_DATA_DIR)
    # Persist so evaluate.py / predict.py always use the exact same order
    # the model was trained with.
    with open(Path(config.MODEL_DIR) / "class_names.json", "w") as f:
        json.dump(class_names, f, indent=2)
    return class_names


def build_augmentation_layer():
    return tf.keras.Sequential([
        tf.keras.layers.RandomFlip("horizontal"),

        tf.keras.layers.RandomRotation(0.10),

        tf.keras.layers.RandomZoom(0.15),

        tf.keras.layers.RandomTranslation(0.10, 0.10),

        tf.keras.layers.RandomContrast(0.15),

        tf.keras.layers.RandomBrightness(0.15),

        tf.keras.layers.GaussianNoise(0.02),
    ], name="augmentation")


def _make_dataset(split, class_names, shuffle, augment):
    split_dir = Path(config.SPLIT_DATA_DIR) / split
    ds = tf.keras.utils.image_dataset_from_directory(
        split_dir,
        labels="inferred",
        label_mode="categorical",
        class_names=class_names,
        image_size=config.IMG_SIZE,
        batch_size=config.BATCH_SIZE,
        shuffle=shuffle,
        seed=config.SEED,
    )

    if augment:
        aug = build_augmentation_layer()
        ds = ds.map(lambda x, y: (aug(x, training=True), y),
                    num_parallel_calls=tf.data.AUTOTUNE)

    # EfficientNet expects its own preprocessing (scales inputs internally),
    # so we do NOT manually rescale to [0,1] here.
    from tensorflow.keras.applications.efficientnet import preprocess_input
    ds = ds.map(lambda x, y: (preprocess_input(x), y),
                num_parallel_calls=tf.data.AUTOTUNE)

    return ds.prefetch(tf.data.AUTOTUNE)


def get_datasets():
    class_names = get_class_names()
    train_ds = _make_dataset("train", class_names, shuffle=True, augment=True)
    val_ds = _make_dataset("val", class_names, shuffle=False, augment=False)
    test_ds = _make_dataset("test", class_names, shuffle=False, augment=False)
    return train_ds, val_ds, test_ds, class_names


def compute_class_weights(class_names):
    """Inverse-frequency class weights so the model doesn't just learn to
    predict the majority class, which is a subtle form of overfitting to
    the training distribution rather than to the underlying task."""
    counts = []
    for cls in class_names:
        cls_dir = Path(config.SPLIT_DATA_DIR) / "train" / cls
        counts.append(len(list(cls_dir.glob("*"))))
    counts = np.array(counts, dtype=np.float32)
    total = counts.sum()
    n_classes = len(counts)
    weights = total / (n_classes * counts)
    return {i: float(w) for i, w in enumerate(weights)}
